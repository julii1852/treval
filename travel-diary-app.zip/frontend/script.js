
document.getElementById('entryForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const location = document.getElementById('location').value;
  const cost = document.getElementById('cost').value;

  const entry = document.createElement('div');
  entry.className = 'entry';
  entry.innerHTML = `<h3>${title}</h3><p>${description}</p><p><strong>Location:</strong> ${location}</p><p><strong>Cost:</strong> ${cost}</p>`;

  document.getElementById('entriesList').appendChild(entry);
  document.getElementById('entryForm').reset();
});
